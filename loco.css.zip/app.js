const slider=document.querySelector(".slider");
const sections=gsap.utils.toArray(".slider section");
console.log(slider)
let tl=gsap.timeline({
    default:{
        ease:"none"
    },
    scrollTrigger:{
        trigger:slider,
        pin:true,
        scrub:2,
        end:()=>"+=" + slider.offsetWidth,
        marker:true,

    }
})
tl.to(slider,{
    xPercent:-80
})