const slider = document.querySelector(".slider");
const sections = gsap.utils.toArray(".slider section");
console.log(slider);
let TL = gsap.timeline({
  default: {
    ease: "none",
  },
  scrollTrigger: {
    trigger: slider,
    pin: true,
    scrub: 2,
    end: () => "+=" + slider.offsetWidth,
    marker: true,
  },
});
TL.to(slider, {
  xPercent: -80,
  smooth: 2,

  // marker:true,
});

let tl = gsap.timeline();
tl.from(".div", {
  width: "90%",
   height: "50vh",
});

tl.to(".div", {
  width: 1800,
  height: 600,
  duration: 1,
  scrollTrigger: {
    trigger: ".div",
    sroller: "body",
    // markers:true,
    start: "top 63%",
    end: "top 20%",
    left: 500,
    scrub: 2,
  },
});
// tl.from(".box",{
//     width:300,
//     height:250,
// })
// tl.to(".box",{
//     width:750,
//     height:500,
//     duration:.5,
//     scrollTrigger:{
//         trigger:".box",
//         sroller:"body",
//         // markers:true,
//         start:"top 63%",
//         end:"top 20%",
//         scrub:2,
//         },
// })

// tl.to(".big-div .div",{
//     width:"1200px",
//     height:"900px",
//     duration:1,
//     scrollTrigger:{
//         trigger:"#main-2 #oo",
//         sroller:"body",
//         markers:true,
//         start:"top 60%",
//         end:"top 20%",
//         scrub:2,
//         },
// })
function openModal() {
    document.getElementById('modalOverlay').style.display = 'flex';
}

function closeModal() {
    document.getElementById('modalOverlay').style.display = 'none';
    // Stop the video when the modal is closed
    var iframe = document.querySelector('iframe');
    var videoSrc = iframe.src;
    iframe.src = videoSrc;
}

// Close modal when clicking outside the modal-content
window.onclick = function(event) {
    var modalOverlay = document.getElementById('modalOverlay');
    if (event.target == modalOverlay) {
        closeModal();
    }
}
